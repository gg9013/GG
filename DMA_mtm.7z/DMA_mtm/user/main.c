#include  "stm32f10x.h"
#include  "led.h"
#include  "DMA_mtm.h"


extern  const uint32_t aSRC_Const_Buffer[BUFFER_SIZE];
extern  uint32_t aDST_Buffer[BUFFER_SIZE];

void Delay(__IO uint32_t nCount);

int main(void)
{
	uint8_t status=0;
	
	LED_GPIO_Config();
	
	LED_YELLOW;
	
	Delay(0xffffff);
	
	MtM_DMA_Config();
	
	while(DMA_GetFlagStatus(mtm_dma_flag) == RESET);
	
	status = Buffercmp(aSRC_Const_Buffer,
			aDST_Buffer,BUFFER_SIZE);
	if(status == 0)
	{
	LED_RED;
	}
	else
	{
	LED_GREEN;
	}
	while(1)
	{
	
	}
}
void Delay(__IO uint32_t nCount)
{
for(;nCount != 0; nCount--);
}

