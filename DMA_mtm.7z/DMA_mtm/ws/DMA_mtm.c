#include "DMA_mtm.h"



const uint32_t aSRC_Const_Buffer[BUFFER_SIZE]={
					0x01020304,0x050f0708,0x09201112,0x13741516,
					0x01022204,0x05090708,0x09301112,0x13641516,
					0x01020304,0x05070708,0x09401112,0x13541516,
					0x01075304,0x05080708,0x09501112,0x13441516,
					0x01072304,0x05080708,0x09601112,0x13341516,
					0x01010304,0x05050708,0x09701112,0x13241516,
					0x01030304,0x05020708,0x09801112,0x13141516,
					0x01050304,0x05000708,0x09901112,0x13041516};

uint32_t aDST_Buffer[BUFFER_SIZE];




void MtM_DMA_Config(void)
{
	DMA_InitTypeDef DMA_InitStruct;
	
	RCC_AHBPeriphClockCmd(Mtm_DMA_Clk,ENABLE);
	
	DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t)aSRC_Const_Buffer;
	DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t) aDST_Buffer;
	DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;
	
	DMA_InitStruct.DMA_BufferSize = BUFFER_SIZE;
	
	DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Enable;
	DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	
	DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	
	DMA_InitStruct.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStruct.DMA_Priority = DMA_Priority_High;
	DMA_InitStruct.DMA_M2M = DMA_M2M_Enable;
	
	DMA_Init(mtm_dma_Channel,&DMA_InitStruct);
	DMA_Cmd(mtm_dma_Channel,ENABLE);
		
}

uint8_t Buffercmp(const uint32_t* pBuffer,
			uint32_t* pBuffer1,uint16_t BufferLenght)
{
while(BufferLenght--)
{
if(*pBuffer != *pBuffer1)
{
return 0;
}
pBuffer++;
pBuffer1++;
}
return 1;
}

