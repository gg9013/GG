#ifndef __DMA_mtm__H
#define __DMA_mtm__H

#include "stm32f10x.h"
#define BUFFER_SIZE 32

#define  Mtm_DMA_Clk  RCC_AHBPeriph_DMA1
#define  mtm_dma_Channel  DMA1_Channel6
#define  mtm_dma_flag  DMA1_FLAG_TC6
void MtM_DMA_Config(void);
uint8_t Buffercmp(const uint32_t* pBuffer,
			uint32_t* pBuffer1,uint16_t BufferLenght);
#endif
