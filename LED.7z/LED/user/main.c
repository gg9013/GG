#include  "stm32f10x.h"
#include  "LED.h"

void delay(uint32_t delaytime)
{
while(delaytime--);
}


int main(void)
{
	LED_GPIO_CONFIG();
while(1)
{
	LED_RED;
	delay(0xfffff);
	LED_GREEN;
	delay(0xfffff);
	LED_BLUE;
	delay(0xfffff);
	LED_YELLOW;
	delay(0xfffff);
	LED_PURPLE;
	delay(0xfffff);
	LED_CYAN;
	delay(0xfffff);
	LED_WHITE;
	delay(0xfffff);
	LED_RGBOFF;
	delay(0xfffff);

}
}


