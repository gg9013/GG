#include "LED.h"

void LED_GPIO_CONFIG(void)
{
	GPIO_InitTypeDef GPIO_Initstructure;
	LED_GPIO_CMD_CLK(LED_GPIO_CLK,ENABLE);
	
	GPIO_Initstructure.GPIO_Pin = LED_GPIO_RED;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(LED_GPIO_PORT,&GPIO_Initstructure);

	GPIO_Initstructure.GPIO_Pin = LED_GPIO_GREEN;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(LED_GPIO_PORT,&GPIO_Initstructure);

	GPIO_Initstructure.GPIO_Pin = LED_GPIO_BLUE;
	GPIO_Initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Initstructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(LED_GPIO_PORT,&GPIO_Initstructure);

	GPIO_SetBits(LED_GPIO_PORT,LED_GPIO_RED);
	GPIO_SetBits(LED_GPIO_PORT,LED_GPIO_GREEN);
	GPIO_SetBits(LED_GPIO_PORT,LED_GPIO_BLUE);
}



