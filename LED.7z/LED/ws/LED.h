#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

#define LED_GPIO_CMD_CLK		RCC_APB2PeriphClockCmd
#define LED_GPIO_CLK		RCC_APB2Periph_GPIOB

#define LED_GPIO_PORT	GPIOB	

#define LED_GPIO_RED		GPIO_Pin_5
#define LED_GPIO_GREEN		GPIO_Pin_0
#define LED_GPIO_BLUE		GPIO_Pin_1

#define DigitalHi(p,i) {p->BSRR=i;}
#define DigitalLo(p,i) {p->BRR=i;}
#define DigitalToggle(p,i) {p->ODR ^=i;}


#define LED_RED_ON		DigitalLo(LED_GPIO_PORT,LED_GPIO_RED)
#define LED_RED_OFF		DigitalHi(LED_GPIO_PORT,LED_GPIO_RED)
#define LED_RED_Toggle		DigitalToggle(LED_GPIO_PORT,LED_GPIO_RED)

#define LED_GREEN_ON		DigitalLo(LED_GPIO_PORT,LED_GPIO_GREEN)
#define LED_GREEN_OFF		DigitalHi(LED_GPIO_PORT,LED_GPIO_GREEN)
#define LED_GREEN_Toggle	DigitalToggle(LED_GPIO_PORT,LED_GPIO_GREEN)

#define LED_BLUE_ON		DigitalLo(LED_GPIO_PORT,LED_GPIO_BLUE)
#define LED_BLUE_OFF		DigitalHi(LED_GPIO_PORT,LED_GPIO_BLUE)
#define LED_BLUE_Toggle		DigitalToggle(LED_GPIO_PORT,LED3_GPIO_BULE)

//������ɫ
//��
#define LED_RED		LED_RED_ON;\
			LED_GREEN_OFF\
			LED_BLUE_OFF
//��
#define LED_GREEN		LED_RED_OFF;\
			LED_GREEN_ON\
			LED_BLUE_OFF
//��
#define LED_BLUE	LED_RED_OFF;\
			LED_GREEN_OFF\
			LED_BLUE_ON
//��
#define LED_YELLOW		LED_RED_ON;\
			LED_GREEN_ON\
			LED_BLUE_OFF
//��
#define LED_PURPLE		LED_RED_ON;\
			LED_GREEN_OFF\
			LED_BLUE_ON
//��
#define LED_CYAN		LED_RED_OFF;\
			LED_GREEN_ON\
			LED_BLUE_ON
//��
#define LED_WHITE		LED_RED_ON;\
			LED_GREEN_ON\
			LED_BLUE_ON
//�ڣ���
#define LED_RGBOFF		LED_RED_OFF;\
			LED_GREEN_OFF\
			LED_BLUE_OFF

void LED_GPIO_CONFIG(void);

#endif /*LED.H*/


