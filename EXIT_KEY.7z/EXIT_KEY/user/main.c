#include  "stm32f10x.h"
#include  "EXIT_KEY.h"
#include  "LED.h"

int main(void)
{
	LED_GPIO_CONFIG();
	EXTI_KEY_CONFIG();
while(1)
{


}
}


