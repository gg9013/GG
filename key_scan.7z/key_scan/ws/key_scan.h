#ifndef __key_scan_H
#define __key_scan_H

#include "stm32f10x.h"

#define KEY_GPIO_CMD_CLK		RCC_APB2PeriphClockCmd

#define KEY1_GPIO_CLK			RCC_APB2Periph_GPIOC
#define KEY2_GPIO_CLK			RCC_APB2Periph_GPIOA

#define KEY1_GPIO_PORT		GPIOC	
#define KEY2_GPIO_PORT		GPIOA

#define KEY1_GPIO		GPIO_Pin_13
#define KEY2_GPIO		GPIO_Pin_0

#define KEY_ON			1
#define KEY_OFF 		0

void  KEY_SCAN_GPIO_CONFIG(void);

uint8_t KEY_SCAN(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);

#endif //key_scan.h


