#include  "stm32f10x.h"
#include  "key_scan.h"
#include  "LED.h"
#include  "WDCZ.h"

int main(void)
{
	LED_GPIO_CONFIG();
	KEY_SCAN_GPIO_CONFIG();
while(1)
{
	if(KEY_SCAN(KEY1_GPIO_PORT,KEY1_GPIO)==KEY_ON)
		LED_RED_Toggle;
	if(KEY_SCAN(KEY2_GPIO_PORT,KEY2_GPIO)==KEY_ON)
		LED_GREEN_Toggle;
	PBout(0) = 0;
}
}


