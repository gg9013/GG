#ifndef  __systick_H
#define  __systick_H

#include "stm32f10x.h"




void Systick_Init(void);
void Delay_us(__IO u32 nTime);
void TimingDelay_Decrement(void);




#endif    //SysTick.H
