#include  "stm32f10x.h"
//#include  "SysTick.h"
#include  "LED.h"
#include  "systick1.h"

int main(void)
{
	LED_GPIO_CONFIG();
//	Systick_Init();
	
while(1)
{
	LED_BLUE_ON;
//	Delay_us(100000);	//��ʱ1000ms	1000*10us=10ms	10000*10us=100ms	100000*10us=1000ms
	SysTick_Delay_Ms(5000);
	
	LED_RED_ON;
//	Delay_us(100000);
	SysTick_Delay_Ms(5000);
	
	LED_GREEN_ON;
//	Delay_us(100000);
	SysTick_Delay_Ms(5000);
}
	
}


